# Day 3: Functions and Scope

This notebook covers:
- Defining and calling functions
- Parameters and return values
- Local vs Global scope
- Default and keyword arguments

## Practice
1. Factorial function
2. Prime check function
3. Try global and local variable demo
